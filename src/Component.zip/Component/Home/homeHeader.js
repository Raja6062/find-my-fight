import React from 'react'
import '../componentStyles.css'

export default function HomeHeader() {
  return (
    <div className="home-header">
      <h3>Welcome to Home Page</h3>
    </div>
  )
}
